#include "fonction-bienvenue.h"
#include <iostream>

void afficherBienvenue()
{
   std::cout << "Bienvenue le monde !" << std::endl;
}
